function woof_init_select_hierarchy() {
    
}
